مشروع تطبيق بوابة النجوم لنظام Android

هذا مشروع Android Studio يفتح نسخة HTML من اللعبة داخل WebView، بوضع أفقي وملء الشاشة.

لإنشاء APK:
1) افتح المشروع في Android Studio.
2) انتظر انتهاء Gradle Sync.
3) اختر Build ثم Build Bundle(s) / APK(s) ثم Build APK(s).
4) ستجد الملف عادةً في app/build/outputs/apk/debug/app-debug.apk

معرّف التطبيق: com.stargate.game
اسم التطبيق: بوابة النجوم

ملاحظة: هذا ملف مشروع وليس APK جاهزاً. يلزم Android Studio أو بيئة بناء Android لإنتاج APK وتوقيعه.
