using UnityEngine;

public class CarDrive : MonoBehaviour
{
    public Rigidbody body;
    [HideInInspector] public float throttle, brake, reverse, steer;
    public float acceleration=9f, reversePower=5f, maxSpeed=13f, turnRate=75f;
    public bool manualMode;
    public int gear=1; // -1 reverse, 0 neutral, 1..5 forward
    float steerInput;

    void FixedUpdate()
    {
        if(!body) return;
        float forward=Vector3.Dot(body.velocity,transform.forward);
        if(manualMode)
        {
            if(gear>0 && throttle>0 && forward<maxSpeed*gear/5f)
                body.AddForce(transform.forward*acceleration*(.55f+gear*.12f),ForceMode.Acceleration);
            if(gear==-1 && throttle>0 && forward>-4f)
                body.AddForce(-transform.forward*reversePower,ForceMode.Acceleration);
        }
        else
        {
            if(throttle>0 && forward<maxSpeed)
                body.AddForce(transform.forward*acceleration,ForceMode.Acceleration);
            if(reverse>0 && forward>-4.5f)
                body.AddForce(-transform.forward*reversePower,ForceMode.Acceleration);
        }
        if(brake>0)
            body.velocity=Vector3.Lerp(body.velocity,Vector3.zero,Time.fixedDeltaTime*4.5f);
        steerInput=Mathf.Lerp(steerInput,steer,Time.fixedDeltaTime*5);
        float speedFactor=Mathf.Clamp01(body.velocity.magnitude/1.5f);
        if(body.velocity.magnitude>.15f)
            body.MoveRotation(body.rotation*Quaternion.Euler(0,steerInput*turnRate*speedFactor*Time.fixedDeltaTime,0));
        throttle=0; reverse=0; brake=0; steer=0;
    }

    public void ShiftGear()
    {
        gear++;
        if(gear>5) gear=-1;
    }
}
