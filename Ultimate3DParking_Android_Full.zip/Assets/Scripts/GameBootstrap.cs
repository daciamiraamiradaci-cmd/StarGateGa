using UnityEngine;

public class GameBootstrap : MonoBehaviour
{
    void Start()
    {
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;
        RenderSettings.ambientLight = new Color(0.62f, 0.66f, 0.72f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(0.70f, 0.76f, 0.82f);
        RenderSettings.fogDensity = 0.008f;

        if (FindObjectOfType<ParkingGame>() == null)
            gameObject.AddComponent<ParkingGame>();
    }
}
