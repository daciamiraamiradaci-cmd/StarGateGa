using UnityEngine;
using System.Collections.Generic;

public class ParkingGame : MonoBehaviour
{
    public int totalStages = 120;
    public int stage = 1;
    public int cameraMode = 0;
    public CarDrive car;
    public Camera gameCamera;
    public Transform parkingZone;
    public string message = "اركن السيارة داخل المكان المحدد";
    public bool stageComplete;
    public int stars;
    public bool showGarage;
    public bool manualGearbox;
    public int selectedCar;
    public int unlockedStage = 1;

    readonly List<GameObject> spawned = new List<GameObject>();
    readonly string[] carNames = { "City Compact", "Sport Coupe", "Classic Sedan", "Urban SUV", "Taxi", "Rally", "Electric", "Luxury", "Pickup", "Supercar" };
    readonly Color[] carColors = {
        new Color(.10f,.34f,.82f), new Color(.82f,.08f,.06f), new Color(.12f,.12f,.14f),
        new Color(.08f,.48f,.24f), new Color(.95f,.72f,.05f), new Color(.95f,.32f,.04f),
        new Color(.10f,.72f,.72f), new Color(.42f,.18f,.65f), new Color(.42f,.28f,.14f), new Color(.9f,.9f,.92f)
    };
    Material roadMat, lineMat, obstacleMat, targetMat, glassMat, buildingMat, sidewalkMat;
    AudioSource engineAudio;
    AudioClip engineClip;
    bool audioReady;

    void Awake()
    {
        Application.targetFrameRate = 60;
        QualitySettings.vSyncCount = 0;
        RenderSettings.ambientLight = new Color(.68f,.70f,.74f);
        RenderSettings.fog = true;
        RenderSettings.fogColor = new Color(.68f,.75f,.82f);
        RenderSettings.fogDensity = .004f;

        unlockedStage = Mathf.Clamp(PlayerPrefs.GetInt("UP_Unlocked", 1), 1, totalStages);
        selectedCar = Mathf.Clamp(PlayerPrefs.GetInt("UP_Car", 0), 0, 9);
        manualGearbox = PlayerPrefs.GetInt("UP_Manual", 0) == 1;
        roadMat = Mat(new Color(.16f,.18f,.20f));
        lineMat = Mat(new Color(.96f,.91f,.72f));
        obstacleMat = Mat(new Color(.95f,.36f,.08f));
        targetMat = Mat(new Color(.12f,.82f,.32f,.42f));
        glassMat = Mat(new Color(.18f,.48f,.58f));
        buildingMat = Mat(new Color(.48f,.53f,.59f));
        sidewalkMat = Mat(new Color(.42f,.44f,.45f));
        BuildCity();
        BuildCar();
        BuildCamera();
        BuildEngineAudio();
        stage = Mathf.Clamp(unlockedStage, 1, totalStages);
        BuildStage();
    }

    Material Mat(Color c)
    {
        var m = new Material(Shader.Find("Standard"));
        m.color = c;
        return m;
    }

    GameObject Cube(string n, Vector3 p, Vector3 s, Material m, bool collider=true, bool stageObject=false)
    {
        var g = GameObject.CreatePrimitive(PrimitiveType.Cube);
        g.name = n;
        g.transform.position = p;
        g.transform.localScale = s;
        if (m) g.GetComponent<Renderer>().material = m;
        if (!collider) Destroy(g.GetComponent<Collider>());
        if (stageObject) spawned.Add(g);
        return g;
    }

    void BuildCity()
    {
        // Large urban asphalt district with intersecting streets and sidewalks.
        Cube("City ground", new Vector3(0,-.55f,0), new Vector3(180,.4f,180), sidewalkMat);
        Cube("Main north-south road", new Vector3(0,-.30f,0), new Vector3(18,.12f,180), roadMat);
        Cube("Main east-west road", new Vector3(0,-.29f,0), new Vector3(180,.12f,18), roadMat);
        for (int i=-4;i<=4;i++)
        {
            Cube("Road marking N-S", new Vector3(i*2,-.22f,0), new Vector3(.07f,.025f,170), lineMat, false);
            Cube("Road marking E-W", new Vector3(0,-.21f,i*2), new Vector3(170,.025f,.07f), lineMat, false);
        }

        // Parking practice area around the central block.
        Cube("Practice lot", new Vector3(0,-.20f,0), new Vector3(38,.12f,42), roadMat);
        for (int x=-4;x<=4;x++)
            Cube("Lot divider", new Vector3(x*3.5f,-.12f,0), new Vector3(.08f,.025f,38), lineMat, false);

        // City blocks: simple building meshes with windows and varied heights.
        for (int ix=-3; ix<=3; ix++)
        for (int iz=-3; iz<=3; iz++)
        {
            if (Mathf.Abs(ix)<=1 && Mathf.Abs(iz)<=1) continue;
            float x=ix*23f, z=iz*23f;
            float h=Random.Range(7f,19f);
            var b=Cube("City building", new Vector3(x,h*.5f,z), new Vector3(Random.Range(10f,15f),h,Random.Range(10f,15f)), buildingMat);
            b.GetComponent<Renderer>().material = Mat(new Color(Random.Range(.35f,.65f),Random.Range(.38f,.68f),Random.Range(.42f,.72f)));
            // Decorative window bands on street-facing side.
            for(int y=2;y<h-1;y+=3)
                Cube("Building window strip",new Vector3(x,h*.5f + y-h*.5f,z- b.transform.localScale.z*.501f),
                     new Vector3(b.transform.localScale.x*.72f,.65f,.035f),glassMat,false);
        }

        // Street lights and small parking-station markers.
        for(int i=-2;i<=2;i++)
        {
            float p=i*25f;
            var pole=Cube("Street lamp pole",new Vector3(11,.9f,p),new Vector3(.18f,1.8f,.18f),lineMat);
            Cube("Street lamp head",new Vector3(11,1.9f,p),new Vector3(.8f,.15f,.35f),lineMat,false);
            Cube("Parking station sign",new Vector3(-11,1.2f,p),new Vector3(.12f,2.4f,.12f),obstacleMat);
            Cube("Parking station board",new Vector3(-11,2.3f,p),new Vector3(1.5f,.75f,.12f),targetMat,false);
        }
        // Outer curb boundary around the training zone.
        Cube("Lot curb north",new Vector3(0,.05f,21),new Vector3(42,.25f,.5f),sidewalkMat);
        Cube("Lot curb south",new Vector3(0,.05f,-21),new Vector3(42,.25f,.5f),sidewalkMat);
        Cube("Lot curb east",new Vector3(21,.05f,0),new Vector3(.5f,.25f,42),sidewalkMat);
        Cube("Lot curb west",new Vector3(-21,.05f,0),new Vector3(.5f,.25f,42),sidewalkMat);
    }

    void BuildCar()
    {
        var root = new GameObject("Player Car");
        root.transform.position = new Vector3(0,.55f,-14);
        var body = GameObject.CreatePrimitive(PrimitiveType.Cube);
        body.name="Body";
        body.transform.SetParent(root.transform,false);
        body.transform.localPosition=new Vector3(0,.15f,0);
        body.transform.localScale=new Vector3(1.85f,.65f,3.8f);
        var rb = root.AddComponent<Rigidbody>();
        rb.mass=1150; rb.drag=.42f; rb.angularDrag=2.8f;
        rb.centerOfMass=new Vector3(0,-.25f,0);
        var drive = root.AddComponent<CarDrive>();
        drive.body=rb;
        var cabin=GameObject.CreatePrimitive(PrimitiveType.Cube);
        cabin.name="Cabin";
        cabin.transform.SetParent(root.transform,false);
        cabin.transform.localPosition=new Vector3(0,.62f,-.1f);
        cabin.transform.localScale=new Vector3(1.45f,.65f,1.8f);
        cabin.GetComponent<Renderer>().material=glassMat;
        Destroy(cabin.GetComponent<Collider>());
        for(int side=-1;side<=1;side+=2)
        for(int z=-1;z<=1;z+=2)
        {
            var w=GameObject.CreatePrimitive(PrimitiveType.Cylinder);
            w.name="Wheel";
            w.transform.SetParent(root.transform,false);
            w.transform.localPosition=new Vector3(side*.94f,-.12f,z*1.25f);
            w.transform.localRotation=Quaternion.Euler(0,0,90);
            w.transform.localScale=new Vector3(.34f,.15f,.34f);
            w.GetComponent<Renderer>().material=Mat(new Color(.025f,.025f,.03f));
            Destroy(w.GetComponent<Collider>());
        }
        car=drive;
        ApplyCarAppearance();
    }

    void ApplyCarAppearance()
    {
        if(!car) return;
        var renderers=car.GetComponentsInChildren<Renderer>();
        foreach(var r in renderers)
        {
            if(r.gameObject.name=="Body")
                r.material=Mat(carColors[selectedCar]);
        }
        car.maxSpeed= selectedCar==9 ? 17f : (selectedCar==6 ? 11f : 13f);
        car.acceleration= selectedCar==9 ? 11f : 9f;
    }

    void BuildCamera()
    {
        var c=new GameObject("Parking Camera");
        gameCamera=c.AddComponent<Camera>();
        c.AddComponent<AudioListener>();
        gameCamera.fieldOfView=62;
    }

    void BuildEngineAudio()
    {
        engineAudio=car.gameObject.AddComponent<AudioSource>();
        engineAudio.loop=true;
        engineAudio.playOnAwake=false;
        engineAudio.volume=.12f;
        engineAudio.spatialBlend=0;
        const int rate=22050, length=2;
        float[] samples=new float[rate*length];
        for(int i=0;i<samples.Length;i++)
        {
            float t=(float)i/rate;
            float wave=Mathf.Sin(2*Mathf.PI*72*t)*.55f +
                       Mathf.Sin(2*Mathf.PI*144*t)*.22f +
                       Mathf.Sin(2*Mathf.PI*216*t)*.10f;
            samples[i]=wave*.22f;
        }
        engineClip=AudioClip.Create("Procedural engine idle",samples.Length,1,rate,false);
        engineClip.SetData(samples,0);
        engineAudio.clip=engineClip;
        engineAudio.Play();
        audioReady=true;
    }

    void ClearStageObjects()
    {
        foreach(var g in spawned.ToArray())
            if(g) Destroy(g);
        spawned.Clear();
    }

    void BuildStage()
    {
        stageComplete=false; stars=0;
        message="المرحلة "+stage+" — اركن داخل المنطقة الخضراء";
        ClearStageObjects();
        float x=((stage*7)%5-2)*2.5f;
        float z=11f;
        parkingZone=new GameObject("Parking Target").transform;
        parkingZone.position=new Vector3(x,.04f,z);
        var target=Cube("Stage_Target",parkingZone.position,new Vector3(2.8f,.08f,5.3f),targetMat,false,true);
        Cube("Stage_left line",new Vector3(x-1.45f,.05f,z),new Vector3(.12f,.06f,5.5f),lineMat,false,true);
        Cube("Stage_right line",new Vector3(x+1.45f,.05f,z),new Vector3(.12f,.06f,5.5f),lineMat,false,true);
        Cube("Stage_back line",new Vector3(x,.05f,z+2.7f),new Vector3(3f,.06f,.12f),lineMat,false,true);

        int count=Mathf.Clamp(1+(stage-1)/7,1,14);
        Random.InitState(stage*7919);
        for(int i=0;i<count;i++)
        {
            float ox=Mathf.Lerp(-10,10,(i+1f)/(count+1f));
            float oz=Random.Range(-5f,8f);
            if(Mathf.Abs(ox-x)<3.3f && Mathf.Abs(oz-z)<4f) oz-=8;
            var o=Cube("Stage_Obstacle_"+i,new Vector3(ox,.55f,oz),new Vector3(1.25f,1.1f,1.25f),obstacleMat,true,true);
            o.transform.rotation=Quaternion.Euler(0,Random.Range(0,25),0);
        }
        car.transform.position=new Vector3(0,.55f,-14);
        car.transform.rotation=Quaternion.identity;
        car.body.velocity=Vector3.zero;
        car.body.angularVelocity=Vector3.zero;
        car.manualMode=manualGearbox;
        ApplyCarAppearance();
    }

    void Update()
    {
        if(!car || !gameCamera) return;
        UpdateCamera();
        if(audioReady)
        {
            float speed=car.body.velocity.magnitude;
            engineAudio.pitch=Mathf.Lerp(.85f,1.8f,Mathf.Clamp01(speed/15f));
            engineAudio.volume=.08f+Mathf.Clamp01(speed/15f)*.12f;
        }
        if(!stageComplete && parkingZone)
        {
            Vector3 local=parkingZone.InverseTransformPoint(car.transform.position);
            bool inside=Mathf.Abs(local.x)<1.05f && Mathf.Abs(local.z)<2.05f;
            float speed=car.body.velocity.magnitude;
            float angle=Quaternion.Angle(car.transform.rotation,Quaternion.identity);
            if(inside && speed<.45f && angle<22f)
            {
                stageComplete=true;
                stars=speed<.15f && angle<8f ? 3 : 2;
                message="ممتاز! اكتملت المرحلة — النجوم: "+stars;
                int old=PlayerPrefs.GetInt("UP_Stars_"+stage,0);
                if(stars>old) PlayerPrefs.SetInt("UP_Stars_"+stage,stars);
                if(stage<totalStages) unlockedStage=Mathf.Max(unlockedStage,stage+1);
                PlayerPrefs.SetInt("UP_Unlocked",unlockedStage);
                PlayerPrefs.Save();
            }
        }
    }

    void UpdateCamera()
    {
        Vector3 pos,look;
        if(cameraMode==0)
        {
            pos=car.transform.position-car.transform.forward*7+Vector3.up*3.2f;
            look=car.transform.position+car.transform.forward*2;
            gameCamera.fieldOfView=62;
        }
        else if(cameraMode==1)
        {
            pos=car.transform.position+car.transform.up*1.15f+car.transform.forward*.35f;
            look=pos+car.transform.forward*9;
            gameCamera.fieldOfView=78;
        }
        else
        {
            pos=car.transform.position+Vector3.up*24;
            look=car.transform.position;
            gameCamera.fieldOfView=58;
        }
        gameCamera.transform.position=Vector3.Lerp(gameCamera.transform.position,pos,Time.deltaTime*7);
        gameCamera.transform.rotation=Quaternion.Slerp(gameCamera.transform.rotation,Quaternion.LookRotation(look-gameCamera.transform.position),Time.deltaTime*7);
    }

    public void NextStage()
    {
        if(!stageComplete) return;
        stage=stage>=totalStages?1:stage+1;
        BuildStage();
    }
    public void ChangeCamera(){cameraMode=(cameraMode+1)%3;}
    public void ResetStage(){BuildStage();}
    public void ChangeGearMode()
    {
        manualGearbox=!manualGearbox;
        car.manualMode=manualGearbox;
        PlayerPrefs.SetInt("UP_Manual",manualGearbox?1:0);
        PlayerPrefs.Save();
    }
    public void SelectCar(int index)
    {
        selectedCar=Mathf.Clamp(index,0,9);
        PlayerPrefs.SetInt("UP_Car",selectedCar);
        PlayerPrefs.Save();
        ApplyCarAppearance();
    }

    void OnGUI()
    {
        GUI.skin.button.fontSize=20;
        GUI.skin.label.fontSize=20;
        GUI.Box(new Rect(10,10,Screen.width-20,84),"");
        GUI.Label(new Rect(22,17,Screen.width*.55f,28),"المرحلة "+stage+" / "+totalStages+"    ⭐ "+PlayerPrefs.GetInt("UP_Stars_"+stage,0));
        GUI.Label(new Rect(22,48,Screen.width-44,36),message);

        float bw=Mathf.Min(130,Screen.width*.23f), bh=58, y=Screen.height-bh-15;
        if(GUI.Button(new Rect(Screen.width-bw-14,14,bw,54),"الكاميرا")) ChangeCamera();
        if(GUI.Button(new Rect(12,y,bw,bh),"◀ يسار")) car.steer=-1;
        if(GUI.Button(new Rect(20+bw,y,bw,bh),"يمين ▶")) car.steer=1;
        if(GUI.RepeatButton(new Rect(Screen.width-bw-14,y-bh-8,bw,bh),"بنزين")) car.throttle=1;
        if(GUI.RepeatButton(new Rect(Screen.width-bw-14,y,bw,bh),"فرامل")) car.brake=1;
        if(GUI.RepeatButton(new Rect(Screen.width-bw-14,y-2*bh-16,bw,bh),"رجوع")) car.reverse=1;
        if(GUI.Button(new Rect(Screen.width*.40f,14,115,54),"إعادة")) ResetStage();
        if(GUI.Button(new Rect(Screen.width*.40f,74,115,48),manualGearbox?"يدوي":"أوتوماتيك")) ChangeGearMode();
        if(GUI.Button(new Rect(12,14,110,54),"المرآب")) showGarage=!showGarage;
        if(GUI.Button(new Rect(Screen.width*.42f,y,120,bh),"توقف")) { car.throttle=0; car.brake=1; car.steer=0; }
        if(stageComplete && GUI.Button(new Rect(Screen.width*.35f,Screen.height*.42f,Screen.width*.38f,70),"المرحلة التالية")) NextStage();

        if(showGarage)
        {
            GUI.Box(new Rect(Screen.width*.12f,Screen.height*.18f,Screen.width*.76f,Screen.height*.62f),"مرآب السيارات — اختر سيارتك");
            for(int i=0;i<10;i++)
            {
                int col=i%2, row=i/2;
                Rect r=new Rect(Screen.width*.17f+col*Screen.width*.36f,Screen.height*.27f+row*Screen.height*.085f,Screen.width*.30f,48);
                string label=(selectedCar==i?"✓ ":"")+carNames[i];
                if(GUI.Button(r,label)) SelectCar(i);
            }
            if(GUI.Button(new Rect(Screen.width*.37f,Screen.height*.72f,Screen.width*.26f,48),"إغلاق المرآب")) showGarage=false;
        }
    }
}
